// Program Title: High School Schedule Generator
/* Program Description:
This program creates conflict-free class schedules for high school students by reading student data, teacher assignments, and classroom information from CSV files. It assigns teachers and classrooms to each student's 8-period day while preventing double-booking conflicts, then displays individual schedules with semester breakdowns and conflict warnings.
Key Functions:
- Loads teacher data and creates extra teachers to make sure there are enough for all classes
- Shows reports of which teachers are available for each grade and subject - Builds the master schedule by filling one period at a time to avoid conflicts
- Lets users pick a student and shows their schedule with colors and clear formatting
- Checks for scheduling problems in real time and keeps track of who's available when
- Checks if data files exist and handles errors when files are missing
*/
// Name: Sahasra Penumadu
// Date: June 12, 2025

package culminating;

import java.util.Scanner; //Import the scanner class from the library
import java.io.File; //Import the File class from the java.io package
import java.io.FileNotFoundException; //Import the FileNotFoundException class from the java.io package

public class CulminatingCS //Class header
{
    // Define ANSI color codes for output formatting
    public static final String RESET = "\u001B[0m"; //Reset color to default
    public static final String ORANGE =  "\u001B[38;2;255;165;0m"; //Orange
    public static final String BLUE =  "\u001B[36m"; //Blue
    public static final String GREEN = "\u001B[32m"; //Green
    public static final String RED = "\u001B[31m"; //Red

    public static void main(String[] args) //Method header
    {
        Scanner keyboard = new Scanner(System.in); //Create a Scanner object
        System.out.println(ORANGE + "HIGH SCHOOL SCHEDULE GENERATOR!" + RESET); //Display programs title in the color orange
        System.out.println(RED + "Scroll to the bottom to select a student and view their schedule!" + RESET);
        System.out.println(ORANGE + "******************************" + RESET); //Underline title

        //Initialize the max limits
        final int MAX_STUDENTS = 100; //Max number of students
        final int MAX_CLASSROOMS = 50; //Max number of classrooms
        final int MAX_TEACHERS = 200; //Max number of teachers
        final int PERIODS_PER_DAY = 8; //Max periods per student
        final int MAX_COURSES_PER_STUDENT = 8; //Max number of courses per student(8)

        //Initialize arrays to store student information
        String[] studentNames = new String[MAX_STUDENTS]; //Array to store student names
        int[] studentGrades = new int[MAX_STUDENTS]; //Array to store student grade levels
        String[][] studentCourses = new String[MAX_STUDENTS][MAX_COURSES_PER_STUDENT]; //2D array for student course schedule
        int studentCount = 0; //Counter to track actual number of students loaded

        //Initialize arrays to store classroom information
        String[] classroomNames = new String[MAX_CLASSROOMS]; //Array to store classroom names/numbers
        int[] classroomCapacity = new int[MAX_CLASSROOMS]; //Array to store classroom capacities
        int classroomCount = 0; //Counter to track actual number of classrooms loaded

        //Initialize arrays to store subject-teacher assignment information
        String[] assignedSubjects = new String[MAX_TEACHERS]; //Array to store subjects each teacher can teach
        int[] assignedGrades = new int[MAX_TEACHERS]; //Array to store grade levels each teacher teaches
        String[] assignedTeachers = new String[MAX_TEACHERS]; //Array to store teacher names
        int assignmentCount = 0; //Counter to track actual number of teacher assignments

        //Initialize scheduling tracking arrays to prevent conflicts
        boolean[][] teacherSchedule = new boolean[PERIODS_PER_DAY][MAX_TEACHERS]; //2D array to track teacher availability by period
        boolean[][] classroomSchedule = new boolean[PERIODS_PER_DAY][MAX_CLASSROOMS]; //2D array to track classroom availability by period
        String[][] periodTeacherAssignments = new String[PERIODS_PER_DAY][MAX_STUDENTS]; //2D array to store final teacher assignments
        String[][] periodClassroomAssignments = new String[PERIODS_PER_DAY][MAX_STUDENTS]; //2D array to store final classroom assignments

        //Load all the data from the csv files into the arrays
        studentCount = loadStudents(studentNames, studentGrades, MAX_STUDENTS); //Load student data and return count
        classroomCount = loadClassrooms(classroomNames, classroomCapacity, MAX_CLASSROOMS); //Load classroom data and return count
        assignmentCount = loadAndExpandTeacherAssignments(assignedSubjects, assignedGrades, assignedTeachers, MAX_TEACHERS); //Load and expand teacher assignments
        loadStudentSchedule(studentNames, studentCourses, studentCount, MAX_COURSES_PER_STUDENT); //Load individual student schedule

        //Display teacher availability report to show staffing levels
        showTeacherReport(assignedSubjects, assignedGrades, assignedTeachers, assignmentCount);
        //Create the master schedule by assigning teachers and classrooms to avoid conflicts
        createMasterSchedule(studentCourses, studentGrades, studentCount, assignedSubjects, assignedGrades, assignedTeachers, assignmentCount, classroomNames, classroomCount, teacherSchedule, classroomSchedule, periodTeacherAssignments, periodClassroomAssignments);

        //Display list of available students for user selection
        System.out.println("\n" + GREEN + "Available Students: " + RESET);
        System.out.println("********************");

        //Loop through all loaded students and display them with numbers
        for (int i = 0; i < studentCount; i++)
        {
            System.out.println((i+1) + ". " + studentNames[i] + " (Grade " + studentGrades[i] + ")");
        }

        //Get user's choice of which student's schedule to display
        System.out.println(); //Add a blank line
        System.out.println(GREEN + "These are all the student enrolled in the school with assigned numbers --> " + RESET);
        System.out.print("Enter the number of the student you want to see the schedule for: ");
        int choice = keyboard.nextInt(); //Read user input and store it in choice

        //Make sure the users choice is within the options and not outside the range
        if(choice < 1 || choice > studentCount)
        {
            System.out.println(RED + "Invalid Choice! Please run the program again." + RESET);
            return; //Exit the program if it's an invalid choice
        }

        //Print the selected student's complete schedule (subtract 1 because index starts at 0)
        printStudentSchedule(studentNames[choice - 1], studentCourses[choice - 1], studentGrades[choice - 1], choice - 1, periodTeacherAssignments, periodClassroomAssignments);

        keyboard.close(); //Close the keyboard so memory is not wasted
    }
        //Method to load and expand teacher assignments (creates multiple teachers per subject for better scheduling)
        public static int loadAndExpandTeacherAssignments(String[] assignedSubjects, int[] assignedGrades, String[] assignedTeachers, int maxTeachers)
        {
            int assignmentCount = 0; //Initialize counter for assignments

            //Load the original teacher assignments from CSV file
            try {
                //Create File object to the teacher assignments CSV file
                File file = new File("G:\\My Drive\\Grade 11\\ICS3U programming files\\Culminating\\src\\culminating\\subject_teacher.csv");
                Scanner scanner = new Scanner(file); //Create Scanner to read the file

                //Skip the header row if it exists
                if(scanner.hasNextLine())
                {
                    scanner.nextLine(); //Skip header line (make sure there is data in the variables)
                }

                //Read each line of the file until end of file or array is full (leaving room for expansions)
                while (scanner.hasNextLine() && assignmentCount < maxTeachers - 50) //Leave room for extra teachers
                {
                    String line = scanner.nextLine(); //Read entire line
                    String[] parts = line.split(","); //Split line by commas

                    //Check if line has all required parts (subject, grade, teacher)
                    if (parts.length >= 3)
                    {
                        assignedSubjects[assignmentCount] = parts[0].trim(); //Store subject name (remove whitespace)
                        assignedGrades[assignmentCount] = Integer.parseInt(parts[1].trim()); //Store grade as integer
                        assignedTeachers[assignmentCount] = parts[2].trim(); //Store teacher name
                        assignmentCount++; //Increment counter
                    }
                }
                scanner.close(); //Close file scanner
                System.out.println("Loaded " + assignmentCount + " original subject teacher assignments."); //Display original number of teachers
            } catch (FileNotFoundException e) //Handle case where CSV file does not exist
            {
                System.out.println("Error subject_teacher.csv file not found");
            }

            //Now create additional teachers for subjects that need more
            int originalCount = assignmentCount; //Remember original count for the expansion calculation

            //For each original assignment, create 2 additional teachers (A and B versions)
            for(int i = 0; i < originalCount && assignmentCount < maxTeachers - 1; i++)
                //Add Teacher A version (same subject/grade but different teacher name)
            {
                assignedSubjects[assignmentCount] = assignedSubjects[i]; //Copy subject
                assignedGrades[assignmentCount] = assignedGrades[i]; //Copy grade
                assignedTeachers[assignmentCount] = assignedTeachers[i] + "A"; //Add "A" suffix to teacher name
                assignmentCount++; //Increment counter

                //Add Teacher B version if there is still room in the array
                if(assignmentCount < maxTeachers - 1) //Check if assignmentCount is less than the number of Max Teachers
                {
                    assignedSubjects[assignmentCount] = assignedSubjects[i]; //Copy subject
                    assignedGrades[assignmentCount] = assignedGrades[i]; //Copy grade
                    assignedTeachers[assignmentCount] = assignedTeachers[i] + "B"; //Add "B" suffix to the teacher name
                    assignmentCount++; //Increment counter
                }
            }

            //Display summary of teacher expansion
            System.out.println("Created " + (assignmentCount - originalCount) + " additional teacher assignments.");
            System.out.println("Total teacher assignments: " + assignmentCount);

            return assignmentCount; //Return total number of teacher assignments
        }

        //Method to show teacher availability report organized by grade level
        public static void showTeacherReport(String[] assignedSubjects, int[] assignedGrades, String[] assignedTeachers, int assignmentCount)
        {
            //Display header for teacher report
            System.out.println(BLUE + "TEACHER AVAILABILITY REPORT" + RESET);
            System.out.println(BLUE + "***************************" + RESET);

            for (int grade = 9; grade <= 12 ; grade++) //Loop through each grade level(9-12)
            {
                System.out.println(GREEN + "Grade " + grade + " Teachers:" + RESET);

                for (int i = 0; i < assignmentCount; i++) //Loop through all teacher assignments to find ones for current grade
                {
                    if(assignedGrades[i] == grade) //If this assignment is for the current grade
                    {
                        String subject = assignedSubjects[i]; //Get the subject name
                        boolean alreadyPrinted = false; //Set a false to avoid duplicate subject listings

                        //Check if this subject has already been processed for this grade
                        for(int k = 0; k < i; k++)
                        {
                            if(assignedGrades[k] == grade && assignedSubjects[k].equals(subject))
                            {
                                alreadyPrinted = true; //Subject already processed

                                break;
                            }
                        }

                        //If this is the first time seeing this subject for this grade
                        if(!alreadyPrinted)
                        {
                            int teacherCount = 0; //Counter for teachers available for this subject/grade

                            //Count all teachers available for this subject and grade
                            for(int j = 0; j < assignmentCount; j++)
                            {
                                if(assignedGrades[j] == grade && assignedSubjects[j].equals(subject))
                                {
                                    teacherCount++; //Increment teacher count
                                }
                            }

                            //Display subject and number of available teachers
                            System.out.println("  " + subject + ": " + teacherCount + " teachers available.");
                        }
                    }
                }

                System.out.println(); //Add blank line after each grade
            }

        }

        //Improved method to create master schedule that avoids conflicts
        public static void createMasterSchedule(String[][] studentCourses, int[] studentGrades, int studentCount, String[] assignedSubjects, int[] assignedGrades, String[] assignedTeachers, int assignmentCount, String[] classroomNames, int classroomCount, boolean[][] teacherSchedule, boolean[][] classroomSchedule, String[][] periodTeacherAssignments, String[][] periodClassroomAssignments)
        {
            System.out.println(RED + "Creating master schedule " + RESET);

            //Process each period first, then each student(this prevents conflicts)
            for(int period = 0; period < 8; period++)
            {
                System.out.println("Scheduling Period " + (period + 1) + ".");

                //For each period, process all students
                for(int student = 0; student < studentCount; student++)
                {
                    String course = studentCourses[student][period]; //Get the course for this student in this period

                    //Only process if student has a course assigned for this period
                    if(course != null && !course.isEmpty())
                    {
                        //Find an available teacher for this course
                        String teacher = findAvailableTeacher(course, studentGrades[student], period, assignedSubjects, assignedGrades, assignedTeachers, assignmentCount, teacherSchedule);
                        //Find an available classroom for this course
                        String classroom = findAvailableClassroom(period, classroomNames, classroomCount, classroomSchedule);

                        //Store the assignments in the master schedule arrays
                        periodTeacherAssignments[period][student] = teacher;
                        periodClassroomAssignments[period][student] = classroom;

                        //Mark teacher as busy for this period (If one was found)
                        if(!teacher.equals("No Available Teacher"))
                        {
                            markTeacherBusy(teacher, period, assignedTeachers, assignmentCount, teacherSchedule);
                        }
                        //Mark classroom as busy for this period (If one was found)
                        if(!classroom.equals("No Available Classroom"))
                        {
                            markClassroomBusy(classroom, period, classroomNames, classroomCount, classroomSchedule);
                        }
                    }
                }
            }

            System.out.println("Master schedule created successfully!");
        }


        //Improved method to find available teacher for a specific course and period
        public static String findAvailableTeacher(String courseName, int grade, int period, String[] assignedSubjects, int[] assignedGrades, String[] assignedTeachers, int assignmentCount, boolean[][] teacherSchedule)
        {
            //Remove grade suffix from course name to get subject (ex. Math_10 becomes Math)
            String subjectName = courseName;
            if(courseName.contains("_"))
            {
                int underscoreIndex = courseName.lastIndexOf("_"); //Find last underscore
                subjectName = courseName.substring(0, underscoreIndex); //Extract subject part
            }

            //Look for teacher who can teach this subject and grade level
            for (int i = 0; i < assignmentCount; i++)
            {
                //Check if teacher teaches this subject and grade
                if(assignedSubjects[i].equals(subjectName) && assignedGrades[i] == grade)
                {
                    //Check if this teacher is available in this period - false = available
                    if(!teacherSchedule[period][i])
                    {
                        return assignedTeachers[i]; //Return first available qualified teacher
                    }
                }
            }
            return "No Available Teacher"; //Return error message if no teacher was found
        }

        //Method to find available classroom for a specific period
        public static String findAvailableClassroom(int period, String[] classroomNames, int classroomCount, boolean[][] classroomSchedule)
        {
            //Look for first available classroom in this period
            for(int i = 0; i<classroomCount; i++)
            {
                //Check if classroom is available (false = available)
                if(!classroomSchedule[period][i])
                {
                    return classroomNames[i]; //Return first available classroom
                }
            }

            return "No Available Classroom"; //Return error message if no classroom found
        }

        //Method to mark teacher as busy for a specific period
        public static void markTeacherBusy(String teacherName, int period, String[] assignedTeachers, int assignmentCount, boolean[][] teacherSchedule)
        {
            //Find teacher index in the array and mark as busy
            for (int i = 0; i < assignmentCount; i++)
            {
                if(assignedTeachers[i].equals(teacherName))
                {
                    teacherSchedule[period][i] = true; //Mark as busy (true = busy)
                    break; //Exit loop once teacher is found and marked
                }
            }
        }

        //Method to mark classroom as busy for a specific period
        public static void markClassroomBusy(String classroomName, int period, String[] classroomNames, int classroomCount, boolean[][] classroomSchedule)
        {
            //Find classroom index in the array and mark as busy
            for (int i = 0; i < classroomCount; i++)
            {
                if(classroomNames[i].equals(classroomName))
                {
                    classroomSchedule[period][i] = true; //Mark as busy (true = busy)
                    break; //Exit loop once classroom is found and marked

                }
            }
        }

        //Method to load students from CSV file
        public static int loadStudents(String[] studentNames, int[] studentGrades, int maxStudents)
        {
            int studentCount = 0; //Initialize counter
            try
            {
                //Create File object pointing to students CSV file
                File file = new File("G:\\My Drive\\Grade 11\\ICS3U programming files\\Culminating\\src\\culminating\\students.csv");
                Scanner scanner = new Scanner(file); //Create scanner to read file

                //Skip header row if it exists
                if(scanner.hasNextLine())
                {
                    scanner.nextLine(); //Skip header
                }

                //Read each line until end of file or array is full
                while(scanner.hasNextLine() && studentCount < maxStudents)
                {
                    String line = scanner.nextLine(); //Read entire line
                    String[] parts = line.split(","); //Split by commas

                    //Check if line has all required parts (name and grade)
                    if(parts.length >= 2)
                    {
                        studentNames[studentCount] = parts[0].trim(); //Store student name and remove whitespace
                        studentGrades[studentCount] = Integer.parseInt((parts[1].trim())); //Store grade as integer
                        studentCount++; //Increment counter
                    }
                }
                scanner.close(); //Close file scanner
                System.out.println("Loaded " + studentCount + " students."); //Print number of students that are loaded
            } catch (FileNotFoundException e) //Handle case where CSV file does not exist
            {
                System.out.println("Error students.csv file not found"); //Tells the user that the file is not found
            }
            return studentCount; //Return the number of students loaded
        }

        //Method to load classrooms from csv file
        public static int loadClassrooms(String[] classroomNames, int[] classroomCapacity, int maxClassrooms)
        {
            int classroomCount = 0; //Initialize counter
            try
            {
                //Create File object pointing to classrooms csv file
                File file = new File("G:\\My Drive\\Grade 11\\ICS3U programming files\\Culminating\\src\\culminating\\classrooms.csv");
                Scanner scanner = new Scanner(file); //Create scanner to read the file

                //Skip header row if it exists
                if(scanner.hasNextLine())
                {
                    scanner.nextLine(); //Skip header
                }

                // Read each line until end of file or array is full
                while(scanner.hasNextLine() && classroomCount < maxClassrooms)
                {
                    String line = scanner.nextLine(); //Read entire line
                    String[] parts = line.split(","); //Split by commas

                    //Check if line has required fields (room name and capacity)
                    if(parts.length >= 2)
                    {
                        classroomNames[classroomCount] = parts[0].trim(); //Store classroom name - remove whitespace
                        classroomCapacity[classroomCount] = Integer.parseInt(parts[1].trim()); //Store capacity as integer
                        classroomCount++; //Increment counter
                    }
                }
                scanner.close(); //Close file scanner
                System.out.println("Loaded " + classroomCount + " classrooms.");

            } catch (FileNotFoundException e) //Handle cases where the CSV file does not exist
            {
                System.out.println("Error classrooms.csv file not found");
            }
            return classroomCount; //Return number of classrooms loaded
        }

        //Method to load student course preferences from CSV file
        public static void loadStudentSchedule(String[] studentNames, String[][] studentCourses, int studentCount, int maxCourses)
        {
            try
            {
                //Create File object pointing to student schedule CSV file
                File file = new File("G:\\My Drive\\Grade 11\\ICS3U programming files\\Culminating\\src\\culminating\\student_schedules1.csv");
                Scanner scanner = new Scanner(file); //Create scanner to read file

                //Skip header row if it exists
                if(scanner.hasNextLine())
                {
                    scanner.nextLine(); //Skip header
                }

                //Read each line of the schedule file
                while(scanner.hasNextLine())
                {
                    String line = scanner.nextLine(); //Read entire line
                    String[] parts = line.split(","); //Split by commas

                    //Check if line has enough fields (name, grade, and 8 courses)
                    if(parts.length >= 10)
                    {
                        String studentName = parts[0].trim(); //Get student name

                        //Find the student in the loaded students array
                        for (int i = 0; i < studentCount; i++)
                        {
                            if(studentNames[i].equals(studentName)) //If names match
                            {
                                //Load course for this student (skip grade and name columns)
                                for (int j = 0; j < maxCourses && j + 2 < parts.length; j++)
                                {
                                    studentCourses[i][j] = parts[j + 2].trim(); //Store course - remove whitespace
                                }
                                break; //Exit loop once student is found and courses are loaded
                            }
                        }
                    }
                }
                scanner.close(); //Close file scanner
                System.out.println("Loaded student course preferences");
                System.out.println(); //Add blank line

            } catch (FileNotFoundException e) //Handle cases where CSV file does not exist
            {
                System.out.println("Error student_schedules1.csv file not found");
            }
        }

        //Method to print individual student's schedule with formatting
        public static void printStudentSchedule(String studentName, String[] courses, int grade, int studentIndex, String[][] periodTeacherAssignments, String[][] periodClassroomAssignments)
        {
            //Print header with the students name and grade
            System.out.println("\n" + BLUE + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" + RESET);
            System.out.println(BLUE + "SCHEDULE FOR: " + studentName + " (Grade " + grade + ")" + RESET);
            System.out.println(BLUE + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" + RESET);

            //Print Semester 1: periods 1-4
            System.out.println("\n" + GREEN + "SEMESTER 1" + RESET);
            System.out.println("-----------");

            //Loop though first 4 periods
            for (int period = 0; period < 4; period++)
            {
                String course = courses[period]; //Get course for this period
                //Only display if the student has a course for this period
                if(course != null && !course.isEmpty())
                {
                    String teacher = periodTeacherAssignments[period][studentIndex]; //Get assigned teacher
                    String classroom = periodClassroomAssignments[period][studentIndex]; //Get assigned classroom

                    //Clean up course name for display (remove grade suffix)
                    String displayCourse = course;
                    if(course.contains("_"))
                    {
                        int underScoreIndex = course.lastIndexOf("_"); //Find last underscore
                        displayCourse = course.substring(0, underScoreIndex); //Extract subject part
                    }

                    //Display period information
                    System.out.println("Period " + (period + 1) + ": " + displayCourse);
                    System.out.println("Teacher: " + teacher);
                    System.out.println("Room: " + classroom);

                    //Add conflict warning if teacher/classroom is not available
                    if(teacher.equals("No Available Teacher"))
                    {
                        System.out.println("   " + RED + "WARNING: No teacher is available" + RESET);
                    }
                    if(classroom.equals("No Available Classroom"))
                    {
                        System.out.println("   " + RED + "WARNING: No classroom is available" + RESET);
                    }

                    //Add blank line
                    System.out.println();
                }
                else
                {
                    //Display message for periods with no course assigned
                    System.out.println("Period " + (period + 1) + ": No course assigned" );
                    System.out.println();
                }
            }

            //Print semester 2 (periods 5-8)
            System.out.println(GREEN + "SEMESTER 2" + RESET);
            System.out.println("-----------");

            //Loop through last 4 periods
            for (int period = 4; period < 8; period++)
            {
                String course = courses[period]; //Get course for this period

                //Only display if student has a course for this period
                if(course != null && !course.isEmpty())
                {
                    String teacher = periodTeacherAssignments[period][studentIndex]; //Get assigned teacher
                    String classroom = periodClassroomAssignments[period][studentIndex]; //Ger assigned classroom

                    //Clean up course name for display (remove grade suffix)
                    String displayCourse = course;
                    if(course.contains("_"))
                    {
                        int underscoreIndex = course.lastIndexOf("_"); //Find last underscore
                        displayCourse = course.substring(0, underscoreIndex); //Extract subject part
                    }

                    //Display period information - renumber period 1-4 for semester 2
                    System.out.println("Period " + (period - 3) + ": " + displayCourse);
                    System.out.println("   Teacher: " + teacher);
                    System.out.println("   Room: " + classroom);

                    //Add conflict warning if teacher/classroom is not available
                    if(teacher.equals("No Available Teacher"))
                    {
                        System.out.println("   " + RED + "WARNING: No teacher is available" + RESET);
                    }
                    if(classroom.equals("No Available Classroom"))
                    {
                        System.out.println("   " + RED + "WARNING: No classroom is available" + RESET);
                    }
                    System.out.println(); //Add blank line
                }
                else
                {
                    //Display message for periods with no course assigned
                    System.out.println("Period " + (period - 3) + ": No course assigned");
                    System.out.println(); //Add blank line
                }
            }

            //Display final message that says the schedule is done generating
            System.out.println(BLUE + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" + RESET);
            System.out.println("Schedule complete for " + studentName + "!");
            System.out.println(BLUE + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" + RESET);
        }
    }

